#pragma once

#include <cmath>
#include <cstdint>
#include <functional>
#include "NoteTypes.h"

namespace MikuMikuWorld
{
	struct Vector2
	{
		float x;
		float y;

		Vector2(float _x, float _y)
			: x{ _x }, y{ _y }
		{

		}

		Vector2() : x{ 0 }, y{ 0 }
		{

		}

		Vector2 operator+(const Vector2& v)
		{
			return Vector2(x + v.x, y + v.y);
		}

		Vector2 operator-(const Vector2& v)
		{
			return Vector2(x - v.x, y - v.y);
		}

		Vector2 operator*(const Vector2& v)
		{
			return Vector2(x * v.x, y * v.y);
		}
	};

	struct Vector3
	{
		float x;
		float y;
		float z;

		Vector3(float _x, float _y, float _z)
			: x{ _x }, y{ _y }, z{ _z }
		{

		}

		Vector3() : x{ 0 }, y{ 0 }, z{ 0 }
		{

		}

		Vector3 operator+(const Vector3& v) const
		{
			return Vector3(x + v.x, y + v.y, z + v.z);
		}

		Vector3 operator-(const Vector3& v) const
		{
			return Vector3(x - v.x, y - v.y, z - v.z);
		}

		Vector3 operator*(const Vector3& v) const
		{
			return Vector3(x * v.x, y * v.y, z * v.z);
		}

		Vector3& operator*=(const Vector3& v)
		{
			x *= v.x;
			y *= v.y;
			z *= v.z;
			return *this;
		}

		Vector3& operator*=(float factor)
		{
			x *= factor;
			y *= factor;
			z *= factor;
			return *this;
		}

		Vector3& operator+=(const Vector3& v)
		{
			x += v.x;
			y += v.y;
			z += v.z;
			return *this;
		}

		inline Vector3 operator * (const float& mult) const {
			return Vector3(x * mult, y * mult, z * mult);
		}
	};

	struct Color
	{
	public:
		float r, g, b, a;

		explicit Color(float _r = 0.0f, float _g = 0.0f, float _b = 0.0f, float _a = 1.0f)
			: r{ _r }, g{ _g }, b{ _b }, a{ _a }
		{

		}
		explicit Color(uint8_t r, uint8_t g, uint8_t b, uint8_t a = 255)
			: r{ r / 255.f }, g{ g / 255.f}, b{ b / 255.f}, a{ a / 255.f }
		{

		}

		inline bool operator==(const Color& c) const { return r == c.r && g == c.g && b == c.b && a == c.a; }
		inline bool operator!=(const Color& c) const { return !(*this == c); }
		inline Color operator*(const Color& c) const { return Color(r * c.r, g * c.g, b * c.b, a * c.a); }

		static inline int rgbaToInt(int r, int g, int b, int a) { return r << 24 | g << 16 | b << 8 | a; }
		static inline int abgrToInt(int a, int b, int g, int r) { return a << 24 | b << 16 | g << 8 | r; }

		inline Color scaleAlpha(float scalar) const { return Color{ r, g, b, a * scalar}; }
	};

	struct Range
	{
		double min;
		double max;
	};

	constexpr uint32_t roundUpToPowerOfTwo(uint32_t v)
	{
		v--;
		v |= v >> 1;
		v |= v >> 2;
		v |= v >> 4;
		v |= v >> 8;
		v |= v >> 16;
		v++;
		return v;
	}

	template <typename FloatType = double>
	static auto roundOff(double value, int precision = 7)
	{
		FloatType dvalue = value;
		double digits = std::pow(10, precision);
		return std::round(dvalue * digits) / digits;
	}

	float lerp(float start, float end, float ratio);
	float unlerp(float start, float end, float value);
	double lerpD(double start, double end, double ratio);
	double unlerpD(double start, double end, double value);
	float easeIn(float start, float end, float ratio);
	float easeOut(float start, float end, float ratio);
	float midpoint(float x1, float x2);
	bool isWithinRange(float x, float left, float right);

	std::function<float(float, float, float)> getEaseFunction(EaseType ease);

	uint32_t gcf(uint32_t a, uint32_t b);

	static constexpr double NUM_PI = 3.14159265358979323846;
	static constexpr double NUM_PI_2 = 3.14159265358979323846 / 2;
	static constexpr double DEGREE_TO_RAD = NUM_PI / 180;

	float easeInCubic(float x);
	float easeOutCubic(float x);
}
